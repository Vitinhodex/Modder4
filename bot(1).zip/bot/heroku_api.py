import os
import tarfile
import tempfile
import asyncio
import heroku3
import requests
from typing import Dict
from pathlib import Path

async def create_heroku_app(api_key: str, app_name: str) -> heroku3.models.app:
    loop = asyncio.get_event_loop()
    heroku_conn = heroku3.from_key(api_key)
    return await loop.run_in_executor(
        None, 
        lambda: heroku_conn.create_app(
            name=app_name,
            stack_id_or_name="container",
        )
    )

async def deploy_to_heroku(api_key: str, app_name: str):
    loop = asyncio.get_event_loop()
    heroku_conn = heroku3.from_key(api_key)
    app = heroku_conn.apps()[app_name]

    # Configura caminhos importantes
    current_dir = Path(__file__).parent
    template_dir = current_dir / "templates"
    
    try:
        # Cria arquivo .env temporário com as variáveis
        temp_dir = await loop.run_in_executor(None, tempfile.mkdtemp)
        
        # Copia todos os arquivos do template para o diretório temporário
        def copy_template():
            os.system(f"cp -r {template_dir}/* {temp_dir}")
            
        await loop.run_in_executor(None, copy_template)

        # Cria o tarball
        tarball_path = os.path.join(temp_dir, "app.tar.gz")
        
        def create_tarball():
            with tarfile.open(tarball_path, "w:gz") as tar:
                tar.add(temp_dir, arcname=os.curdir)
                
        await loop.run_in_executor(None, create_tarball)

        # Obtém URL para upload
        headers = {
            "Accept": "application/vnd.heroku+json; version=3",
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        
        # Passo 1: Solicitar URL de upload
        sources_url = f"https://api.heroku.com/apps/{app.name}/sources"
        response = await loop.run_in_executor(
            None,
            lambda: requests.post(sources_url, headers=headers)
        )
        response.raise_for_status()
        source_blob = response.json()["source_blob"]
        
        # Passo 2: Fazer upload do tarball
        with open(tarball_path, "rb") as f:
            upload_response = await loop.run_in_executor(
                None,
                lambda: requests.put(
                    source_blob["put_url"],
                    data=f.read(),
                    headers={"Content-Type": "application/gzip"}
                )
            )
        upload_response.raise_for_status()

        # Passo 3: Iniciar build
        build_data = {
            "source_blob": {
                "url": source_blob["get_url"],
                "version": "1.0"
            }
        }
        build_url = f"https://api.heroku.com/apps/{app.name}/builds"
        build_response = await loop.run_in_executor(
            None,
            lambda: requests.post(build_url, json=build_data, headers=headers)
        )
        build_response.raise_for_status()

        # Monitorar status do build
        build_id = build_response.json()["id"]
        status = "pending"
        
        while status not in ["succeeded", "failed"]:
            await asyncio.sleep(5)
            status_url = f"https://api.heroku.com/apps/{app.name}/builds/{build_id}"
            status_response = await loop.run_in_executor(
                None,
                lambda: requests.get(status_url, headers=headers)
            )
            status = status_response.json()["status"]
            
        if status == "failed":
            raise Exception("Build failed on Heroku")

    except requests.exceptions.RequestException as e:
        error_msg = f"Heroku API Error: {str(e)}"
        if hasattr(e, "response") and e.response is not None:
            error_msg += f" - {e.response.text}"
        raise Exception(error_msg)
        
    finally:
        # Limpeza dos arquivos temporários
        def cleanup():
            os.system(f"rm -rf {temp_dir}")
            
        await loop.run_in_executor(None, cleanup)

async def update_config(app: heroku3.models.app, config: Dict[str, str]):
    loop = asyncio.get_event_loop()
    await loop.run_in_executor(
        None,
        lambda: app.update_config(config)
    )