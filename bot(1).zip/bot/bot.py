import os
import logging
import asyncio
from dotenv import load_dotenv
from telegram import Update, ReplyKeyboardRemove
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    filters,
    ContextTypes,
)
from heroku_api import create_heroku_app, deploy_to_heroku

# Carrega variáveis de ambiente
load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN")
HEROKU_API_KEY = os.getenv("HEROKU_API_KEY")

# Configura logging
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)
logger = logging.getLogger(__name__)

# Dados temporários de usuários (em memória)
user_data = {}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🚀 Bem-vindo ao Bot de Deploy Automático!\n"
        "Envie /deploy <SEU_TOKEN> para começar."
    )

async def deploy(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    args = context.args

    if not args:
        await update.message.reply_text("⚠️ Uso correto: /deploy <TOKEN_DO_SEU_BOT>")
        return

    token = args[0]
    user_data[user_id] = {"token": token, "user_id": None}

    await update.message.reply_text("🔑 Agora, envie seu USER_ID:")

async def handle_user_id(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    client_user_id = update.message.text

    if user_id not in user_data or not user_data[user_id].get("token"):
        await update.message.reply_text("❌ Erro: Use /deploy primeiro.")
        return

    try:
        # Atualiza dados do usuário
        user_data[user_id]["user_id"] = client_user_id

        # Cria app no Heroku
        app_name = f"bot-{user_id}-{os.urandom(2).hex()}"
        app = await create_heroku_app(HEROKU_API_KEY, app_name)

        # Configura variáveis de ambiente
        await app.update_config({
            "TOKEN": user_data[user_id]["token"],
            "USER_ID": client_user_id
        })

        # Faz deploy do template
        await deploy_to_heroku(HEROKU_API_KEY, app.name)

        # Resposta ao usuário
        await update.message.reply_text(
            f"✅ Deploy concluído!\n"
            f"🔗 URL: https://{app.name}.herokuapp.com\n"
            f"📊 Verifique os logs no Heroku Dashboard."
        )

    except Exception as e:
        logger.error(f"Erro no deploy: {str(e)}")
        await update.message.reply_text(f"❌ Falha no deploy: {str(e)}")
    finally:
        if user_id in user_data:
            del user_data[user_id]

async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    logger.error(f"Erro: {context.error}")
    await update.message.reply_text("⚠️ Ocorreu um erro durante o processamento.")

def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()

    # Handlers
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("deploy", deploy))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_user_id))
    app.add_error_handler(error_handler)

    # Inicia o bot
    app.run_polling()

if __name__ == "__main__":
    main()