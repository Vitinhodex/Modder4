
import os
from datetime import datetime, timedelta, timezone
import paramiko
import logging
import base64
import string
from telegram import InputFile
import secrets  
from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    filters,
    ConversationHandler,
    CallbackContext,
    CallbackQueryHandler
)
import paramiko
import sqlite3
import asyncio
from backup_restore import create_backup, restore_backup
from telegram.ext import filters
import requests
import mercadopago
from datetime import datetime, timedelta
from telegram import Update
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    filters,
    ConversationHandler,
    CallbackContext,
    CallbackQueryHandler
)
import logging


load_dotenv()
TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
MERCADOPAGO_TOKEN = os.getenv("MERCADOPAGO_ACCESS_TOKEN")
REFERENCE_CHANNEL = os.getenv("REFERENCE_CHANNEL")  # Nome ou ID do canal


ADMIN_IDS = [int(id) for id in os.getenv("ADMIN_IDS", "").split(",") if id]
PLAN_EMAIL = 10
RENEWAL_DAYS = 30  
RENEWAL_PRICE = 15.0  



SERVER_NAME, SERVER_HOST, SERVER_PORT, SERVER_USER, SERVER_PASS = range(5)
(APP_LINK_SELECT, APP_LINK_EDIT) = range(5, 7)  
EDIT_PLAN_FIELD, EDIT_PLAN_VALUE = range(2)
BROADCAST, SELECT_BROADCAST_TYPE, CONFIRM_BROADCAST = range(10, 13)
MAINTENANCE_MODE = False  


conn = sqlite3.connect('servidoar.db', check_same_thread=False)
cursor = conn.cursor()

# No início do script principal, após criar a conexão:
def restart_db_connection():
    global conn, cursor
    if conn:
        conn.close()
    conn = sqlite3.connect('servidoar.db', check_same_thread=False)
    cursor = conn.cursor()
    migrate_db()  # Re-executar migrações se necessário

def migrate_db():
    try:

        cursor.execute("PRAGMA table_info(payments)")
        columns = [column[1] for column in cursor.fetchall()]

        if 'days' not in columns:
            print("Iniciando migração do banco de dados...")


            cursor.execute('''
                CREATE TABLE payments_new (
                    id INTEGER PRIMARY KEY,
                    user_id INTEGER,
                    plan_id INTEGER,
                    payment_id TEXT UNIQUE,
                    status TEXT,
                    amount REAL,
                    created_at TEXT,
                    expiry_date TEXT,
                    transaction_type TEXT,
                    days INTEGER  
                )
            ''')


            cursor.execute('''
                INSERT INTO payments_new (
                    id, user_id, plan_id, payment_id, status, amount, 
                    created_at, expiry_date, transaction_type
                )
                SELECT 
                    id, user_id, plan_id, payment_id, status, amount, 
                    created_at, expiry_date, transaction_type
                FROM payments
            ''')


            cursor.execute('DROP TABLE payments')
            cursor.execute('ALTER TABLE payments_new RENAME TO payments')
            conn.commit()
            print("Migração concluída com sucesso!")

    except Exception as e:
        print("Erro durante a migração:", str(e))
        conn.rollback()

def migrate_plans_table():
    try:
        cursor.execute("PRAGMA table_info(plans)")
        columns = [column[1] for column in cursor.fetchall()]
        
        if 'device_limit' not in columns:
            # Alterar DEFAULT para 9999
            cursor.execute('ALTER TABLE plans ADD COLUMN device_limit INTEGER DEFAULT 9999')
            conn.commit()
            logging.info("Coluna device_limit adicionada à tabela plans")
            
    except sqlite3.Error as e:
        logging.error(f"Erro na migração: {str(e)}")
        conn.rollback()
        
cursor.execute('''
    CREATE TABLE IF NOT EXISTS servers (
        id INTEGER PRIMARY KEY,
        name TEXT,
        host TEXT,
        port INTEGER,
        user TEXT,
        password TEXT
    )
''')
conn.commit()  

# Adicione isso junto com as outras CREATE TABLE
cursor.execute('''
    CREATE TABLE IF NOT EXISTS mp_tokens (
        id INTEGER PRIMARY KEY,
        token TEXT NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )
''')
conn.commit()

# Adicione junto com as outras CREATE TABLE
cursor.execute('''
    CREATE TABLE IF NOT EXISTS app_files (
        id INTEGER PRIMARY KEY,
        file_id TEXT,
        file_name TEXT,
        uploaded_at TEXT DEFAULT CURRENT_TIMESTAMP
    )
''')
conn.commit()

cursor.execute('''
    CREATE TABLE IF NOT EXISTS renewal_settings (
        id INTEGER PRIMARY KEY,
        days INTEGER DEFAULT 30,
        price REAL DEFAULT 15.0
    )
''')

cursor.execute('INSERT OR IGNORE INTO renewal_settings (id) VALUES (1)')
conn.commit()



cursor.execute('''
    CREATE TABLE IF NOT EXISTS trial_cooldown (
        user_id INTEGER PRIMARY KEY,
        last_trial_date TEXT
    )
''')
conn.commit()


cursor.execute('''
    CREATE TABLE IF NOT EXISTS plans (
        id INTEGER PRIMARY KEY,
        name TEXT,
        duration_days INTEGER,
        price REAL,
        device_limit INTEGER DEFAULT 1,
        active BOOLEAN DEFAULT 1
    )
''')
conn.commit()

cursor.execute('''
    CREATE TABLE IF NOT EXISTS payments (
        id INTEGER PRIMARY KEY,
        user_id INTEGER,
        plan_id INTEGER,
        payment_id TEXT UNIQUE,
        status TEXT,
        amount REAL,
        created_at TEXT,
        expiry_date TEXT,
        transaction_type TEXT,
        days INTEGER  
    )
''')
conn.commit()

migrate_plans_table()
migrate_db

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

def get_mp_token():
    try:
        cursor.execute('SELECT token FROM mp_tokens ORDER BY created_at DESC LIMIT 1')
        result = cursor.fetchone()
        return result[0] if result else None
    except sqlite3.Error as e:
        logging.error(f"Erro ao buscar token MP: {str(e)}")
        return None

async def notify_admins(context: CallbackContext, message: str):
    """Envia notificação para todos os administradores"""
    for admin_id in ADMIN_IDS:
        try:
            await context.bot.send_message(
                chat_id=admin_id,
                text=message,
                parse_mode="MarkdownV2"
            )
        except Exception as e:
            logging.error(f"Erro ao notificar admin {admin_id}: {str(e)}")  
                      
def generate_random_username():
    """Gera um nome de usuário aleatório de 6 caracteres alfanuméricos"""
    characters = string.ascii_lowercase + string.digits
    return ''.join(secrets.choice(characters) for _ in range(6))
        
async def start(update: Update, context: CallbackContext):
    if update.callback_query:
        query = update.callback_query
        await query.answer()
        message = query.message
    else:
        message = update.message

    # Busca o último arquivo cadastrado
    cursor.execute('SELECT file_id, file_name FROM app_files ORDER BY uploaded_at DESC LIMIT 1')
    file = cursor.fetchone()

    if file:
        file_id, file_name = file
        download_link = f"📥 Baixar {file_name}"
    else:
        download_link = "⚠️ Nenhum arquivo disponível no momento."

    user = update.effective_user
    welcome_message = (
        f"👋 Olá {user.first_name}!\n\n"
        "Adquira a melhor internet ilimitada do Brasil. Lembre-se de que eu sou um bot e responderei apenas à sua solicitação nos comandos abaixo, ok?\n\n"
        "Clique em um dos botões abaixo para que eu atenda à sua solicitação."
    )

    keyboard = [
        [
            InlineKeyboardButton("⏳ Teste Grátis", callback_data='trial'),
            InlineKeyboardButton("🛒 Comprar Login", callback_data='buy')
        ],
        [
            InlineKeyboardButton("🔄 Renovar", callback_data='renew'),
            InlineKeyboardButton("📱 Baixar app", callback_data='download_app')
        ],
        [
            InlineKeyboardButton("💬 Suporte", url='https://t.me/onwdev')
        ]
    ]

    if user.id in ADMIN_IDS:
        keyboard.append([
            InlineKeyboardButton("👑 Painel Admin", callback_data='admin_menu')
        ])

    try:
        if update.callback_query:
            await message.edit_text(
                text=welcome_message,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="Markdown",
                disable_web_page_preview=True
            )
        else:
            await message.reply_text(
                text=welcome_message,
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode="Markdown",
                disable_web_page_preview=True
            )
    except Exception as e:
        logging.error(f"Erro no start: {str(e)}")
                        
async def main_menu(update: Update, context: CallbackContext):
    query = update.callback_query
    await query.answer()

    keyboard = [
        [InlineKeyboardButton("🆓 Teste Grátis (3h)", callback_data='trial')],
        [InlineKeyboardButton("💸 Comprar Acesso", callback_data='buy')],
        [InlineKeyboardButton("📲 Download App", url='https://exemplo.com/download')]
    ]

    if query.from_user.id in ADMIN_IDS:
        keyboard.append([InlineKeyboardButton("⚙️ Admin", callback_data='admin_menu')])

    await query.message.edit_text(
        "🔒 Bem-vindo à VPN Premium!\nEscolha uma opção:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def admin_menu(update: Update, context: CallbackContext):
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id not in ADMIN_IDS:
        await query.message.reply_text("❌ Acesso restrito a administradores!")
        return
    
    keyboard = [
        [InlineKeyboardButton("➕ Adicionar Plano", callback_data='add_plan'),
         InlineKeyboardButton("✏️ Editar Planos", callback_data='edit_plans')],
        [InlineKeyboardButton("🚫 Desativar Planos", callback_data='list_plans_to_disable'),
         InlineKeyboardButton("🔗 Editar Links", callback_data='edit_app_links')],
        [InlineKeyboardButton("📤 Enviar Mensagem", callback_data='broadcast')],
        [InlineKeyboardButton("🖥️ Gerenciar Servidores", callback_data='manage_servers'),
         InlineKeyboardButton("🔑 Token MP", callback_data='set_mp_token')],
        [InlineKeyboardButton("🔙 Voltar", callback_data='start')]
    ]
    
    await query.message.edit_text(
        "⚙️ *Menu de Administração*:\nSelecione uma opção:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )        
    
PLAN_NAME, PLAN_DURATION, PLAN_PRICE, PLAN_DEVICE_LIMIT = range(4)

async def add_plan(update: Update, context: CallbackContext):
    """Inicia o processo de adição de um novo plano."""
    query = update.callback_query
    if query:
        await query.answer()
        message = query.message
    else:
        message = update.message

    # Verifica se o usuário é um administrador
    if update.effective_user.id not in ADMIN_IDS:
        await message.reply_text("❌ Acesso restrito a administradores!")
        return ConversationHandler.END

    # Inicia o processo de adição de plano
    await message.reply_text("📝 Digite o nome do novo plano:")
    return PLAN_NAME

async def plan_name(update: Update, context: CallbackContext):
    """Armazena o nome do plano e solicita a duração."""
    plan_name = update.message.text.strip()
    if not plan_name:
        await update.message.reply_text("❌ O nome do plano não pode estar vazio. Tente novamente:")
        return PLAN_NAME

    context.user_data['new_plan'] = {'name': plan_name}
    await update.message.reply_text("⏳ Digite a duração do plano em dias:")
    return PLAN_DURATION

async def plan_duration(update: Update, context: CallbackContext):
    """Armazena a duração do plano e solicita o preço."""
    try:
        duration = int(update.message.text.strip())
        if duration <= 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Duração inválida! Digite um número inteiro maior que 0:")
        return PLAN_DURATION

    context.user_data['new_plan']['duration'] = duration
    await update.message.reply_text("💲 Digite o preço do plano (ex: 29.90):")
    return PLAN_PRICE

async def plan_price(update: Update, context: CallbackContext):
    """Armazena o preço do plano e finaliza o cadastro"""
    try:
        price = float(update.message.text.strip())
        if price <= 0:
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Preço inválido! Digite um número válido (ex: 29.90):")
        return PLAN_PRICE

    # Salva o plano com device_limit fixo em 9999
    try:
        cursor.execute('''
            INSERT INTO plans (name, duration_days, price, device_limit)
            VALUES (?, ?, ?, 9999)
        ''', (
            context.user_data['new_plan']['name'],
            context.user_data['new_plan']['duration'],
            price
        ))
        conn.commit()

        await update.message.reply_text(
            f"✅ *Plano adicionado com sucesso!*\n\n"
            f"📝 Nome: {context.user_data['new_plan']['name']}\n"
            f"⏳ Duração: {context.user_data['new_plan']['duration']} dias\n"
            f"💲 Preço: R${price:.2f}\n",
            parse_mode="Markdown"
        )
        context.user_data.pop('new_plan', None)

    except sqlite3.Error as e:
        logging.error(f"Erro ao salvar plano: {str(e)}")
        await update.message.reply_text("❌ Erro ao salvar o plano!")

    return ConversationHandler.END
            
async def handle_plan_selection(update: Update, context: CallbackContext):
    query = update.callback_query
    plan_id = query.data.split('_')[1]

    cursor.execute('SELECT * FROM plans WHERE id = ?', (plan_id,))
    plan = cursor.fetchone()

    context.user_data['selected_plan'] = {
        'id': plan[0],
        'name': plan[1],
        'days': plan[2],
        'price': plan[3]
    }

    await query.message.reply_text("📧 Por favor, digite seu e-mail para gerar o PIX:")
    context.user_data['awaiting_email'] = True

async def show_plans(update: Update, context: CallbackContext):
    cursor.execute('SELECT * FROM plans WHERE active = 1')
    plans = cursor.fetchall()

    keyboard = []

    for plan in plans:
        keyboard.append([InlineKeyboardButton(
            f"{plan[1]} - {plan[2]} dias | R${plan[3]:.2f}",
            callback_data=f"plan_{plan[0]}"
        )])

    keyboard.append([InlineKeyboardButton("🔙 Voltar", callback_data='start')])

    await update.callback_query.edit_message_text(
        "📊 Planos Disponíveis:\n\n"
        "Selecione o plano desejado:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def start_payment(update: Update, context: CallbackContext):
    query = update.callback_query
    await query.answer()
    await query.message.reply_text("📧 Por favor, digite seu e-mail para gerar o PIX:")
    context.user_data['awaiting_email'] = True

async def handle_payment_email(update: Update, context: CallbackContext):
    if context.user_data.get('awaiting_email'):
        email = update.message.text
        user = update.message.from_user

        try:
            is_renewal = 'renewal' in context.user_data
            transaction_type = "renewal" if is_renewal else "new"

            if is_renewal:
                plan_data = context.user_data['renewal']
                plan_id = plan_data['new_plan_id']
            else:
                plan_id = context.user_data['selected_plan']['id']

            cursor.execute('SELECT * FROM plans WHERE id = ?', (plan_id,))
            plan = cursor.fetchone()
            if not plan:
                raise ValueError("Plano não encontrado")

            selected_plan = {
                'id': plan[0],
                'name': plan[1],
                'days': plan[2],
                'price': plan[3]
            }

            if '@' not in email:
                await update.message.reply_text("❌ Email inválido. Digite novamente:")
                return

            # Verifica se o token MP está configurado
            mp_token = get_mp_token()
            if not mp_token:
                await update.message.reply_text("❌ Serviço de pagamentos indisponível. Administradores foram notificados.")
                await notify_admins(context, "🚨 ATENÇÃO: Token do Mercado Pago não configurado!")
                return

            sdk = mercadopago.SDK(mp_token)
            expiration_date = (datetime.now(timezone.utc) + timedelta(minutes=30)).strftime('%Y-%m-%dT%H:%M:%S.000-03:00')

            payment_data = {
                "transaction_amount": float(selected_plan['price']),
                "description": f"{selected_plan['name']} - {selected_plan['days']} dias",
                "payment_method_id": "pix",
                "payer": {
                    "email": email,
                    "first_name": user.first_name,
                    "last_name": user.last_name or "",
                },
                "date_of_expiration": expiration_date,
                "metadata": {
                    "user_id": user.id,
                    "plan_id": selected_plan['id'],
                    "type": transaction_type
                }
            }

            payment_response = sdk.payment().create(payment_data)
            if payment_response['status'] not in [200, 201]:
                error_msg = payment_response.get('response', {}).get('message', 'Erro no gateway')
                raise Exception(f"Erro MP: {error_msg}")

            payment = payment_response["response"]

            created_at = datetime.now(timezone.utc)
            expiry_date = created_at + timedelta(days=selected_plan['days'])

            cursor.execute('''
                INSERT INTO payments 
                (user_id, plan_id, payment_id, status, amount, created_at, expiry_date, transaction_type, days)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                user.id,
                selected_plan['id'],
                payment['id'],
                payment['status'],
                selected_plan['price'],
                created_at.strftime('%Y-%m-%d %H:%M:%S'),
                expiry_date.strftime('%Y-%m-%d %H:%M:%S'),
                transaction_type,
                selected_plan['days']
            ))
            conn.commit()

            qr_code = payment["point_of_interaction"]["transaction_data"]["qr_code"]
            qr_base64 = payment["point_of_interaction"]["transaction_data"]["qr_code_base64"]
            qr_image = base64.b64decode(qr_base64)

            message_text = f"""
✅ Pagamento Gerado!

💰 Valor: {selected_plan['price']:.2f}

Pegue o código Pix abaixo para que seu acesso seja enviado. Certifique-se de realizar o pagamento corretamente

`{qr_code}`

🕓 Validade: {selected_plan['days']} dias

✅ Após a confirmação do pagamento, seu acesso será enviado automaticamente."""

            sent_message = await update.message.reply_photo(
                photo=qr_image,
                caption=message_text,
                parse_mode="Markdown"
            )

            context.job_queue.run_repeating(
                auto_check_payment,
                interval=30,
                first=10,
                data={
                    'payment_id': payment['id'],
                    'user_id': user.id,
                    'chat_id': sent_message.chat_id
                },
                name=f"payment_check_{payment['id']}"
            )

            context.user_data.pop('awaiting_email', None)
            context.user_data.pop('selected_plan', None)
            context.user_data.pop('renewal', None)

        except Exception as e:
            logging.error(f"ERRO: {str(e)}", exc_info=True)
            await update.message.reply_text(
                f"❌ *Falha no pagamento!*\nMotivo: `{str(e)}`\n\nTente novamente ou contate o suporte.",
                parse_mode="Markdown"
            )

# Função para notificar compras no canal de referência
async def notify_purchase(context: CallbackContext, user_id: int, product_name: str):
    """
    Envia uma notificação no canal de referência sobre a compra realizada.
    
    Args:
        context (CallbackContext): Contexto do Telegram.
        user_id (int): ID do usuário que realizou a compra.
        product_name (str): Nome do produto comprado.
    """
    # ID do canal de referência (substitua pelo ID real do seu canal)
    REFERENCE_CHANNEL_ID = "@popnet_grupo"

    # Mensagem profissional com detalhes da compra
    message = (
        f"📦 *Nova Compra Registrada!*\n\n"
        f"👤 *ID do Usuário:* `{user_id}`\n"
        f"🛍️ *Produto Adquirido:* `{product_name}`\n"
        f"📅 *Data da Compra:* `{datetime.now().strftime('%d/%m/%Y %H:%M')}`\n\n"
        f"🔗 Acesse o bot para mais informações!"
    )

    # Botão com link direto para o bot
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("🤖 Abrir Bot", url="https://t.me/PopNetssh_bot")]
    ])

    try:
        # Enviar mensagem para o canal de referência
        await context.bot.send_message(
            chat_id=REFERENCE_CHANNEL_ID,
            text=message,
            reply_markup=keyboard,
            parse_mode="Markdown"
        )
    except Exception as e:
        logging.error(f"Erro ao notificar compra no canal: {str(e)}")


# Função principal de verificação automática de pagamentos
async def auto_check_payment(context: CallbackContext):
    try:
        job = context.job
        data = job.data
        payment_id = data['payment_id']
        user_id = data['user_id']
        chat_id = data['chat_id']

        # Obter token MP dinamicamente
        mp_token = get_mp_token()
        if not mp_token:
            logging.error("Token MP não configurado!")
            await context.bot.send_message(
                chat_id=chat_id,
                text="❌ Erro de configuração do sistema de pagamentos. Administradores foram notificados."
            )
            await notify_admins(context, "🚨 ERRO: Token MP não configurado durante verificação de pagamento")
            job.schedule_removal()
            return

        sdk = mercadopago.SDK(mp_token)
        payment = sdk.payment().get(payment_id)

        if payment['status'] not in [200, 201]:
            logging.error(f"Erro ao verificar pagamento {payment_id}: {payment}")
            await context.bot.send_message(
                chat_id=chat_id,
                text="⚠️ Erro temporário na verificação. Tente novamente em alguns minutos."
            )
            return

        status = payment['response']['status']
        if status == 'approved':
            cursor.execute('''
                SELECT p.expiry_date, pl.duration_days, pl.name, pl.device_limit 
                FROM payments p
                JOIN plans pl ON p.plan_id = pl.id
                WHERE p.payment_id = ?
            ''', (payment_id,))
            result = cursor.fetchone()
            
            if not result:
                raise Exception("Pagamento não encontrado no banco de dados")

            expiry_date_str, duration_days, plan_name, device_limit = result
            expiry_date = datetime.strptime(expiry_date_str, '%Y-%m-%d %H:%M:%S').replace(tzinfo=timezone.utc)

            # VALIDAÇÃO DO DEVICE_LIMIT
            device_limit = 9999  # Forçar dispositivo ilimitado

            if datetime.now(timezone.utc) > expiry_date:
                await context.bot.send_message(
                    chat_id=chat_id,
                    text="⚠️ A validade do plano já expirou! Contate o suporte."
                )
                job.schedule_removal()
                return

            # Seleciona um servidor aleatório
            cursor.execute('SELECT * FROM servers ORDER BY RANDOM() LIMIT 1')
            server = cursor.fetchone()
            if not server:
                raise Exception("Nenhum servidor disponível")

            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            try:
                ssh.connect(
                    hostname=server[2],
                    port=int(server[3]),
                    username=server[4],
                    password=server[5],
                    timeout=15,
                    banner_timeout=20
                )

                # Gera um nome de usuário único
                username = None
                for _ in range(10):  # Tenta até 10 vezes para evitar colisões
                    candidate = generate_random_username()
                    check_cmd = f"id -u {candidate} >/dev/null 2>&1"
                    stdin, stdout, stderr = ssh.exec_command(check_cmd)
                    if stdout.channel.recv_exit_status() != 0:  # Usuário não existe
                        username = candidate
                        break
                if not username:
                    raise Exception("Não foi possível gerar um nome de usuário único após 10 tentativas")

                password = f"{secrets.randbelow(10000):04}"  # Gera uma senha numérica de 4 dígitos
                expiry_date_server = expiry_date.strftime('%Y-%m-%d')

                # Comando para criar o usuário e aplicar o limite de dispositivos
                command = f"""
                # Verifica se o openssl está instalado
                if ! which openssl >/dev/null; then
                    sudo apt-get update && sudo apt-get install -y openssl
                fi

                # Verifica se o módulo pam_limits está habilitado
                if ! grep 'pam_limits.so' /etc/pam.d/sshd >/dev/null; then
                    echo 'session required pam_limits.so' | sudo tee -a /etc/pam.d/sshd
                fi

                # Cria ou atualiza o usuário
                if id -u {username} >/dev/null 2>&1; then
                    echo "{username}:{password}" | sudo chpasswd
                    sudo usermod -e {expiry_date_server} {username}
                else
                    sudo useradd -M -s /bin/false {username}
                    echo "{username}:{password}" | sudo chpasswd
                    sudo usermod -e {expiry_date_server} {username}
                fi

                # Aplica o limite de dispositivos
                echo -e "{username}\\thard\\tmaxlogins\\t9999" | sudo tee /etc/security/limits.d/{username}.conf
                sudo chmod 644 /etc/security/limits.d/{username}.conf

                # Reinicia o serviço SSH
                sudo systemctl restart sshd
                """

                # Executa o comando
                stdin, stdout, stderr = ssh.exec_command(command)
                exit_code = stdout.channel.recv_exit_status()

                if exit_code == 0:
                    cursor.execute('''
                        UPDATE payments 
                        SET status = 'approved'
                        WHERE payment_id = ?
                    ''', (payment_id,))
                    conn.commit()

                    # Notifica o usuário sobre a aprovação
                    await context.bot.send_message(
                        chat_id=chat_id,
                        text=f"""
✅ *PAGAMENTO APROVADO!*
➖➖➖➖➖➖➖➖➖
🔐 Usuário: `{username}`
🔑 Senha: `{password}`
⏳ Validade: {expiry_date.strftime('%d/%m/%Y às %H:%M')}
➖➖➖➖➖➖➖➖➖
""",
                        parse_mode="Markdown",
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("📱 Baixar App", callback_data='send_app')]
                        ])
                    )
                    
                    # Notifica o canal de referência sobre a compra
                    await notify_purchase(
                        context=context,
                        user_id=user_id,
                        product_name=plan_name
                    )
                    
                    job.schedule_removal()
                else:
                    error = stderr.read().decode()
                    raise Exception(f"Erro SSH ({exit_code}): {error}")

            except Exception as ssh_error:
                logging.error(f"Erro SSH: {str(ssh_error)}")
                await context.bot.send_message(
                    chat_id=chat_id,
                    text="⚠️ Erro na criação do acesso. Contate o suporte!"
                )
                await notify_admins(context, f"🚨 ERRO SSH: {str(ssh_error)}")
                
            finally:
                ssh.close()

        elif status in ['rejected', 'cancelled']:
            await context.bot.send_message(
                chat_id=chat_id,
                text=f"❌ Pagamento {status.upper()}! Por favor tente novamente."
            )
            job.schedule_removal()

        elif datetime.now(timezone.utc) > datetime.fromisoformat(payment['response']['date_of_expiration']):
            await context.bot.send_message(
                chat_id=chat_id,
                text="⚠️ Pagamento expirado! Gere um novo QR Code."
            )
            job.schedule_removal()

    except Exception as e:
        logging.error(f"Erro na verificação automática: {str(e)}", exc_info=True)
        await context.bot.send_message(
            chat_id=chat_id,
            text="⚠️ Ocorreu um erro ao verificar seu pagamento. Contate o suporte!"
        )
        await notify_admins(context, f"🚨 ERRO CRÍTICO: {str(e)}")
        job.schedule_removal()
                                                                                
async def handle_server_info(update: Update, context: CallbackContext):

    pass

async def create_trial_user_v2(update: Update, context: CallbackContext):
    query = update.callback_query
    await query.answer()
    user = query.from_user

    # Verificação de cooldown
    cursor.execute('SELECT last_trial_date FROM trial_cooldown WHERE user_id = ?', (user.id,))
    result = cursor.fetchone()

    if result:
        last_date = datetime.fromisoformat(result[0])
        cooldown_period = timedelta(hours=24)
        if (datetime.now() - last_date) < cooldown_period:
            remaining_time = cooldown_period - (datetime.now() - last_date)
            remaining_hours = int(remaining_time.total_seconds() // 3600)
            await query.message.reply_text(
                f"⏳ Você precisa aguardar {remaining_hours} hora(s) para criar outro teste grátis!",
                parse_mode="Markdown"
            )
            return

    # Seleciona servidor aleatório
    cursor.execute('SELECT * FROM servers ORDER BY RANDOM() LIMIT 1')
    server = cursor.fetchone()

    if not server:
        await query.message.reply_text("❌ Nenhum servidor disponível!")
        return

    # Extrai dados do servidor
    _, _, host, port, ssh_user, ssh_pass = server

    # Gera credenciais únicas para o teste grátis
    trial_id = secrets.randbelow(10000)
    username = f"teste{trial_id:04}"
    password = f"{secrets.randbelow(10000):05}"

    try:
        # Conecta ao servidor via SSH
        with paramiko.SSHClient() as ssh:
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(
                hostname=host,
                port=int(port),
                username=ssh_user,
                password=ssh_pass,
                timeout=20,
                auth_timeout=15,
                banner_timeout=15
            )

            # Calcula a expiração do teste (1 hora)
            expiry_time = datetime.now() + timedelta(hours=1)
            expiry_cron = expiry_time.strftime('%M %H %d %m *')

            # Cria o usuário e agenda a remoção com cron
            create_cmd = f"""
            useradd -M -s /bin/false {username} &&
            echo "{username}:{password}" | chpasswd &&
            (crontab -l 2>/dev/null; echo "{expiry_cron} sudo /usr/sbin/userdel -f {username}") | crontab -
            """

            stdin, stdout, stderr = ssh.exec_command(create_cmd)
            exit_code = stdout.channel.recv_exit_status()

            if exit_code != 0:
                error = stderr.read().decode().strip()
                raise Exception(f"Erro {exit_code}: {error}")

            # Atualiza cooldown no banco de dados
            cursor.execute('''
                INSERT OR REPLACE INTO trial_cooldown (user_id, last_trial_date)
                VALUES (?, ?)
            ''', (user.id, datetime.now().isoformat()))
            conn.commit()

            # Formata a mensagem de sucesso
            expiry_human = expiry_time.strftime('%d/%m/%Y às %H:%M')
            message = (
                "✅ *Seu teste foi criado com sucesso!*, aqui estão os dados da sua conta SSH para conectar:\n\n"
                f"👤 *Usuário:* `{username}`\n"
                f"🔑 *Senha:* `{password}`\n"
                f"🗓️ *Duração:* 1 hora(s)\n"
                f"📲 *Limite:* 1 dispositivo\n\n"
                "📌 *Clique no nome de usuário e na senha para copiar!*"
            )

            await query.message.reply_text(
                message,
                parse_mode="Markdown",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("📱 Baixar App", callback_data='send_app')]
                ])
            )

    except paramiko.AuthenticationException:
        await query.message.reply_text(
            "🔒 *Erro de autenticação SSH!* Verifique as credenciais do servidor.",
            parse_mode="Markdown"
        )
    except paramiko.SSHException as e:
        logging.error(f"SSH Error: {str(e)}")
        await query.message.reply_text(
            "🚨 *Erro na conexão SSH:*\n`O servidor não respondeu corretamente`",
            parse_mode="Markdown"
        )
    except Exception as e:
        logging.error(f"Trial Error: {str(e)}")
        await query.message.reply_text(
            f"❌ *Falha crítica:*\n`{str(e)}`",
            parse_mode="Markdown"
        )
        conn.rollback()
                                                                                        
async def add_server(update: Update, context: CallbackContext):
    query = update.callback_query
    if query:
        await query.answer()
        message = query.message
    else:
        message = update.message

    user_id = update.effective_user.id
    if user_id not in ADMIN_IDS:
        await message.reply_text("❌ Acesso restrito a administradores!")
        return ConversationHandler.END

    await message.reply_text("Informe o nome do servidor:")
    return SERVER_NAME  

async def server_name(update: Update, context: CallbackContext):
    context.user_data['server_name'] = update.message.text
    logging.info(f"Servidor nome: {update.message.text}")
    await update.message.reply_text("Informe o host/IP do servidor:")
    return SERVER_HOST


async def server_host(update: Update, context: CallbackContext):
    context.user_data['server_host'] = update.message.text
    await update.message.reply_text("Informe a porta do servidor:")
    return SERVER_PORT

async def server_port(update: Update, context: CallbackContext):
    try:
        port = int(update.message.text)
        if not (1 <= port <= 65535):
            raise ValueError
        context.user_data['server_port'] = port
        await update.message.reply_text("Informe o usuário do servidor:")
        return SERVER_USER
    except ValueError:
        await update.message.reply_text("❌ Porta inválida! Digite um número entre 1 e 65535:")
        return SERVER_PORT

async def server_user(update: Update, context: CallbackContext):
    context.user_data['server_user'] = update.message.text
    await update.message.reply_text("Informe a senha do servidor:")
    return SERVER_PASS

async def server_pass(update: Update, context: CallbackContext):
    context.user_data['server_pass'] = update.message.text
    cursor.execute('''
        INSERT INTO servers (name, host, port, user, password)
        VALUES (?, ?, ?, ?, ?)
    ''', (
        context.user_data['server_name'],
        context.user_data['server_host'],
        context.user_data['server_port'],
        context.user_data['server_user'],
        context.user_data['server_pass']
    ))
    conn.commit()
    await update.message.reply_text("Servidor cadastrado com sucesso!")
    return ConversationHandler.END

async def edit_plans(update: Update, context: CallbackContext):
    query = update.callback_query
    await query.answer()

    cursor.execute('SELECT * FROM plans')
    plans = cursor.fetchall()

    keyboard = []
    for plan in plans:
        status = "✅ Ativo" if plan[4] else "🚫 Inativo"
        keyboard.append([
            InlineKeyboardButton(
                f"{plan[1]} - {status}",
                callback_data=f"edit_plan_{plan[0]}"
            )
        ])

    keyboard.append([InlineKeyboardButton("🔙 Voltar", callback_data='admin_menu')])

    await query.message.edit_text(
        "📝 Planos para edição:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def disable_plan(update: Update, context: CallbackContext):
    """Desativa um plano selecionado."""
    query = update.callback_query
    await query.answer()
    
    try:
        plan_id = query.data.split('_')[2]
        logging.info(f"Tentando desativar plano ID: {plan_id}")

        # Verifica se o plano existe
        cursor.execute('SELECT * FROM plans WHERE id = ?', (plan_id,))
        plan = cursor.fetchone()
        
        if not plan:
            logging.error(f"Plano {plan_id} não encontrado")
            await query.message.reply_text("❌ Plano não encontrado!")
            return

        # Executa a desativação
        cursor.execute('''
            UPDATE plans 
            SET active = 0 
            WHERE id = ?
        ''', (plan_id,))
        conn.commit()

        if cursor.rowcount == 0:
            logging.warning(f"Nenhuma alteração no plano {plan_id}")
            await query.message.reply_text("⚠️ Nenhum plano foi alterado. Verifique o ID.")
        else:
            logging.info(f"Plano {plan_id} desativado com sucesso")
            await query.message.edit_text(f"✅ Plano {plan[1]} (ID: {plan_id}) desativado!")

    except IndexError:
        logging.error("Formato inválido do callback_data")
        await query.message.reply_text("❌ Erro: Formato de comando inválido")
    except sqlite3.Error as e:
        logging.error(f"Erro de banco de dados: {str(e)}")
        await query.message.reply_text("❌ Erro interno ao acessar o banco de dados")
    except Exception as e:
        logging.error(f"Erro inesperado: {str(e)}")
        await query.message.reply_text("❌ Ocorreu um erro inesperado")
                                
async def manage_servers(update: Update, context: CallbackContext):
    query = update.callback_query
    await query.answer()

    cursor.execute('SELECT * FROM servers')
    servers = cursor.fetchall()

    keyboard = []
    for server in servers:
        keyboard.append([
            InlineKeyboardButton(
                f"🖥 {server[1]}",
                callback_data=f"server_{server[0]}"
            )
        ])

    keyboard.append([
        InlineKeyboardButton("➕ Adicionar Servidor", callback_data='add_server'),
        InlineKeyboardButton("🔙 Voltar", callback_data='admin_menu')
    ])

    await query.message.edit_text(
        "🖥️ Servidores cadastrados:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def cancel(update: Update, context: CallbackContext):
    await update.message.reply_text('Operação cancelada!')
    return ConversationHandler.END

async def check_payment(update: Update, context: CallbackContext):
    query = update.callback_query
    payment_id = query.data.split('_')[1]

    try:
        sdk = mercadopago.SDK(MERCADOPAGO_TOKEN)
        payment = sdk.payment().get(payment_id)

        if payment['status'] != 200:
            logging.error(f"Erro MercadoPago: {payment}")
            await query.answer("❌ Falha na verificação do pagamento")
            return

        status = payment['response']['status']
        if status != 'approved':
            await query.answer(f"⏳ Status atual: {status}")
            return


        cursor.execute('''
            SELECT p.*, pl.duration_days 
            FROM payments p
            JOIN plans pl ON p.plan_id = pl.id
            WHERE p.payment_id = ?
        ''', (payment_id,))
        payment_data = cursor.fetchone()

        if not payment_data:
            logging.error(f"Pagamento não encontrado: {payment_id}")
            await query.answer("❌ Pagamento não registrado!")
            return

        user_id = payment_data[1]
        plan_duration = payment_data[9]  
        expiry_date = datetime.now() + timedelta(days=plan_duration)


        cursor.execute('SELECT * FROM servers ORDER BY RANDOM() LIMIT 1')
        server = cursor.fetchone()

        if not server:
            logging.error("Nenhum servidor cadastrado no banco de dados")
            await query.answer("❌ Configuração incompleta!")
            return


        username = f"user_{user_id}"
        password = secrets.token_urlsafe(8)  

        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())


            ssh.connect(
                hostname=server[2],
                port=int(server[3]),
                username=server[4],
                password=server[5],
                timeout=15,
                banner_timeout=20
            )


            check_cmd = f"id -u {username} >/dev/null 2>&1"
            stdin, stdout, stderr = ssh.exec_command(check_cmd)

            if stdout.channel.recv_exit_status() == 0:

                command = f"""
                echo "{username}:{password}" | chpasswd &&
                usermod -e {expiry_date.strftime('%Y-%m-%d')} {username}
                """
                action = "atualizado"
            else:

                command = f"""
                useradd -M -s /bin/false {username} && 
                echo "{username}:{password}" | chpasswd && 
                usermod -e {expiry_date.strftime('%Y-%m-%d')} {username}
                """
                action = "criado"


            stdin, stdout, stderr = ssh.exec_command(command)
            exit_status = stdout.channel.recv_exit_status()
            errors = stderr.read().decode().strip()

            if exit_status != 0:
                error_msg = f"SSH Error [{exit_status}]: {errors}"
                logging.error(error_msg)
                raise Exception(error_msg)


            cursor.execute('''
                UPDATE payments 
                SET status = ?, expiry_date = ?
                WHERE payment_id = ?
            ''', (
                'approved',
                expiry_date.strftime('%Y-%m-%d %H:%M:%S'),
                payment_id
            ))
            conn.commit()


            try:
                await context.bot.send_message(
                    chat_id=user_id,
                    text=(
                        "✅ *ACESSO CRIADO COM SUCESSO!*\n\n"
                        f"🔐 *Usuário:* `{username}`\n"
                        f"🔑 *Senha:* `{password}`\n"
                        f"⏳ *Validade:* {expiry_date.strftime('%d/%m/%Y às %H:%M')}\n\n"
                        "📥 *Aplicativo:*\n"
                        "[Clique para baixar](https://build.dtunnel.com.br/uploads/118f7894a4/4.3.13_base_ssh.apk)\n\n"
                        "🔧 *Problemas de conexão?*\n"
                        "Contate nosso suporte: @Vitinho_Mods"
                    ),
                    parse_mode="Markdown",
                    disable_web_page_preview=True
                )
            except Exception as msg_error:
                logging.error(f"Erro ao enviar mensagem: {str(msg_error)}")
                raise Exception("Falha no envio das credenciais")

            await query.answer("✅ Login ativado! Verifique suas mensagens")

        except paramiko.AuthenticationException:
            error_msg = "Falha na autenticação SSH"
            logging.error(error_msg)
            raise Exception("Problema na configuração do servidor")

        except paramiko.SSHException as e:
            error_msg = f"Erro SSH: {str(e)}"
            logging.error(error_msg)
            raise Exception("Falha na comunicação com o servidor")

        finally:
            if ssh:
                ssh.close()

    except Exception as e:
        logging.error(f"ERRO CRÍTICO: {str(e)}", exc_info=True)
        await query.answer("❌ Falha na ativação! Contate o suporte")


        admin_msg = f"🚨 ERRO AO PROCESSAR PAGAMENTO:\nID: {payment_id}\nErro: {str(e)}"
        for admin in ADMIN_IDS:
            try:
                await context.bot.send_message(chat_id=admin, text=admin_msg)
            except Exception as admin_error:
                logging.error(f"Erro ao notificar admin: {str(admin_error)}")

async def renew_access(update: Update, context: CallbackContext):
    query = update.callback_query
    if query:
        await query.answer()
        await query.message.reply_text("🔁 Digite o nome de usuário que deseja renovar:")
    else:
        await update.message.reply_text("🔁 Digite o nome de usuário que deseja renovar:")

    context.user_data['renewal_flow'] = True
    return "AWAITING_RENEWAL_USERNAME"

async def handle_renewal_username(update: Update, context: CallbackContext):
    username = update.message.text.strip()
    context.user_data['renewal_username'] = username

    try:

        cursor.execute('SELECT * FROM servers')
        servers = cursor.fetchall()
        user_exists = False
        found_server = None

        for server in servers:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            try:
                ssh.connect(
                    hostname=server[2],
                    port=int(server[3]),
                    username=server[4],
                    password=server[5],
                    timeout=10,
                    banner_timeout=15
                )


                stdin, stdout, stderr = ssh.exec_command(f"getent passwd {username}")
                exit_code = stdout.channel.recv_exit_status()

                if exit_code == 0:
                    user_exists = True
                    found_server = server
                    break

            except Exception as e:
                logging.error(f"Erro ao conectar no servidor {server[1]}: {str(e)}")
            finally:
                ssh.close()

        if not user_exists:
            await update.message.reply_text("❌ Usuário não encontrado em nenhum servidor!")
            return ConversationHandler.END


        context.user_data['renewal_server'] = found_server

        await update.message.reply_text("📧 Por favor, digite seu e-mail para gerar o PIX de renovação:")
        return "AWAITING_RENEWAL_EMAIL"

    except Exception as e:
        logging.error(f"Erro na verificação do usuário: {str(e)}")
        await update.message.reply_text("⚠️ Erro ao verificar o usuário. Tente novamente.")
        return ConversationHandler.END

async def handle_renewal_email(update: Update, context: CallbackContext):
    email = update.message.text
    context.user_data['renewal_email'] = email

    try:

        cursor.execute('SELECT days, price FROM renewal_settings WHERE id = 1')
        renewal_settings = cursor.fetchone()
        days = renewal_settings[0]
        price = renewal_settings[1]


        sdk = mercadopago.SDK(MERCADOPAGO_TOKEN)
        payment_data = {
            "transaction_amount": float(price),
            "description": f"Renovação de acesso - {days} dias",
            "payment_method_id": "pix",
            "payer": {"email": email},
            "metadata": {
                "type": "renewal",
                "username": context.user_data['renewal_username']
            }
        }

        payment_response = sdk.payment().create(payment_data)
        payment = payment_response["response"]


        cursor.execute("PRAGMA table_info(payments)")
        columns = [column[1] for column in cursor.fetchall()]

        if 'days' not in columns:

            cursor.execute('''
                CREATE TABLE payments_new (
                    id INTEGER PRIMARY KEY,
                    user_id INTEGER,
                    plan_id INTEGER,
                    payment_id TEXT UNIQUE,
                    status TEXT,
                    amount REAL,
                    created_at TEXT,
                    expiry_date TEXT,
                    transaction_type TEXT,
                    days INTEGER  -- Coluna nova
                )
            ''')


            cursor.execute('''
                INSERT INTO payments_new (
                    id, user_id, plan_id, payment_id, status, amount, 
                    created_at, expiry_date, transaction_type
                )
                SELECT 
                    id, user_id, plan_id, payment_id, status, amount, 
                    created_at, expiry_date, transaction_type
                FROM payments
            ''')


            cursor.execute('DROP TABLE payments')
            cursor.execute('ALTER TABLE payments_new RENAME TO payments')
            conn.commit()


        cursor.execute('''
            INSERT INTO payments 
            (user_id, payment_id, status, amount, created_at, expiry_date, transaction_type, days)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            update.message.from_user.id,
            payment['id'],
            'pending',
            price,
            datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S'),
            (datetime.now(timezone.utc) + timedelta(days=days)).strftime('%Y-%m-%d %H:%M:%S'),
            'renewal',
            days  
        ))
        conn.commit()


        qr_code = payment["point_of_interaction"]["transaction_data"]["qr_code"]
        qr_base64 = payment["point_of_interaction"]["transaction_data"]["qr_code_base64"]
        qr_image = base64.b64decode(qr_base64)

        await update.message.reply_photo(
            photo=qr_image,
            caption=f"""
🔁 *PAGAMENTO PARA RENOVAÇÃO*
➖➖➖➖➖➖➖➖
👤 Usuário: `{context.user_data['renewal_username']}`
⏳ Dias: {days} dias
💲 Valor: R${price:.2f}
➖➖➖➖➖➖➖➖
🔖 Código PIX: `{qr_code}`
            """,
            parse_mode="Markdown"
        )


        context.job_queue.run_repeating(
            check_renewal_payment,
            interval=30,
            first=10,
            data={
                'payment_id': payment['id'],
                'username': context.user_data['renewal_username'],
                'days': days,
                'chat_id': update.message.chat_id
            },
            name=f"renewal_check_{payment['id']}"
        )

        return ConversationHandler.END

    except Exception as e:
        logging.error(f"Erro no processo de renovação: {str(e)}", exc_info=True)
        await update.message.reply_text("❌ Erro ao processar a renovação. Tente novamente ou contate o suporte.")
        return ConversationHandler.END

async def check_renewal_payment(context: CallbackContext):
    job = context.job
    payment_id = job.data['payment_id']
    username = job.data['username']
    chat_id = job.data['chat_id']

    try:

        sdk = mercadopago.SDK(MERCADOPAGO_TOKEN)
        payment = sdk.payment().get(payment_id)

        if payment['status'] != 200:
            logging.error(f"Erro na API Mercado Pago: {payment}")
            await context.bot.send_message(
                chat_id=chat_id,
                text="⚠️ Erro na verificação do pagamento. Tente novamente."
            )
            job.schedule_removal()
            return

        status = payment['response']['status']


        cursor.execute('''
            SELECT expiry_date, days 
            FROM payments 
            WHERE payment_id = ?
        ''', (payment_id,))
        result = cursor.fetchone()

        if not result:
            logging.error(f"Pagamento {payment_id} não encontrado no banco de dados")
            await context.bot.send_message(
                chat_id=chat_id,
                text="⚠️ Erro interno: Transação não registrada."
            )
            job.schedule_removal()
            return

        expiry_date_str, days = result
        expiry_date = datetime.fromisoformat(expiry_date_str).replace(tzinfo=timezone.utc)


        if status == 'approved':
            if datetime.now(timezone.utc) > expiry_date:
                await context.bot.send_message(
                    chat_id=chat_id,
                    text="⚠️ Validade expirada! Gere um novo pagamento."
                )
                job.schedule_removal()
                return


            success = False
            cursor.execute('SELECT * FROM servers')
            servers = cursor.fetchall()

            for server in servers:
                try:
                    ssh = paramiko.SSHClient()
                    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                    ssh.connect(
                        hostname=server[2],
                        port=int(server[3]),
                        username=server[4],
                        password=server[5],
                        timeout=15,
                        banner_timeout=20
                    )

                    new_expiry = (datetime.now(timezone.utc) + timedelta(days=days)).strftime('%Y-%m-%d')
                    stdin, stdout, stderr = ssh.exec_command(f"usermod -e {new_expiry} {username}")

                    if stdout.channel.recv_exit_status() == 0:
                        success = True
                        break

                except Exception as e:
                    logging.error(f"Erro no servidor {server[1]}: {str(e)}")
                finally:
                    ssh.close()

            if success:

                cursor.execute('''
                    UPDATE payments 
                    SET status = 'approved'
                    WHERE payment_id = ?
                ''', (payment_id,))
                conn.commit()

                await context.bot.send_message(
                    chat_id=chat_id,
                    text=f"✅ Renovação concluída!\nUsuário: {username}\nValidade: +{days} dias"
                )
            else:
                await context.bot.send_message(
                    chat_id=chat_id,
                    text="⚠️ Falha na renovação. Contate o suporte!"
                )

            job.schedule_removal()

        elif status in ['rejected', 'cancelled']:
            await context.bot.send_message(
                chat_id=chat_id,
                text=f"❌ Pagamento {status.upper()}! Tente novamente."
            )
            job.schedule_removal()

        elif datetime.now(timezone.utc) > datetime.fromisoformat(payment['response']['date_of_expiration']):
            await context.bot.send_message(
                chat_id=chat_id,
                text="⚠️ Pagamento expirado! Gere um novo QR Code."
            )
            job.schedule_removal()

    except Exception as e:
        logging.error(f"Erro crítico: {str(e)}", exc_info=True)
        await context.bot.send_message(
            chat_id=chat_id,
            text="⚠️ Erro interno! Contate o suporte."
        )
        job.schedule_removal()               


async def edit_renewal(update: Update, context: CallbackContext):
    if update.message.from_user.id not in ADMIN_IDS:
        await update.message.reply_text("❌ Acesso restrito!")
        return

    await update.message.reply_text("Quantos dias para renovação? (Atual: {RENEWAL_DAYS})")
    return "AWAITING_RENEWAL_DAYS"

async def set_renewal_days(update: Update, context: CallbackContext):
    try:
        days = int(update.message.text)
        cursor.execute('UPDATE renewal_settings SET days = ? WHERE id = 1', (days,))
        conn.commit()

        await update.message.reply_text(f"✅ Dias de renovação alterados para {days}")
        return "AWAITING_RENEWAL_PRICE"
    except ValueError:
        await update.message.reply_text("❌ Valor inválido! Digite um número inteiro.")
        return "AWAITING_RENEWAL_DAYS"

async def set_renewal_price(update: Update, context: CallbackContext):
    try:
        price = float(update.message.text)
        cursor.execute('UPDATE renewal_settings SET price = ? WHERE id = 1', (price,))
        conn.commit()

        await update.message.reply_text(f"✅ Preço de renovação alterado para R${price:.2f}")
        return ConversationHandler.END
    except ValueError:
        await update.message.reply_text("❌ Valor inválido! Digite um número (ex: 25.90).")
        return "AWAITING_RENEWAL_PRICE"
        
async def set_mp_token(update: Update, context: CallbackContext):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text("❌ Acesso restrito a administradores!")
        return ConversationHandler.END
    
    await update.message.reply_text("🔑 Por favor, envie o novo token do Mercado Pago:")
    return "AWAITING_MP_TOKEN"

async def start_set_token(update: Update, context: CallbackContext):
    """Inicia o processo de configuração do token"""
    try:
        if update.callback_query:
            query = update.callback_query
            await query.answer()
            message = query.message
            user = query.from_user
        else:
            message = update.message
            user = update.effective_user

        if user.id not in ADMIN_IDS:
            await message.reply_text("❌ Acesso restrito a administradores!")
            return ConversationHandler.END

        # Mensagem corrigida com MarkdownV2 válido
        reply_text = (
            "🔑 *ENVIE O TOKEN DO MERCADO PAGO\\!*\n\n"
            "1\\. Acesse o [Portal de Desenvolvedores]("
            "https://www\\.mercadopago\\.com\\.br/developers)\n"
            "2\\. Crie/Copie seu *Access Token*\n"
            "3\\. Cole aqui o token \\(começa com `APP_USR\\-`\\)"
        )

        if update.callback_query:
            await message.edit_text(
                reply_text,
                parse_mode="MarkdownV2",
                disable_web_page_preview=True
            )
        else:
            await message.reply_text(
                reply_text,
                parse_mode="MarkdownV2",
                disable_web_page_preview=True
            )

        return "WAITING_MP_TOKEN"

    except Exception as e:
        logging.error(f"Erro em start_set_token: {str(e)}")
        return ConversationHandler.END
                      
async def save_mp_token(update: Update, context: CallbackContext):
    """Valida e salva o token no banco de dados"""
    token = update.message.text.strip()
    logging.info(f"Token recebido: {token[:15]}...")
    
    try:
        # Verificação de administrador
        if update.effective_user.id not in ADMIN_IDS:
            await update.message.reply_text(
                "❌ *Acesso restrito a administradores\\!*",
                parse_mode="MarkdownV2"
            )
            return ConversationHandler.END

        # Validação básica do formato
        if not token.startswith('APP_USR-'):
            raise ValueError("O token deve começar com 'APP_USR\\-'\nEx: APP_USR\\-1234567890123456\\-123456\\-abcdef...")

        if len(token) < 45 or len(token) > 200:
            raise ValueError("Token muito curto ou longo\\. Verifique o formato completo\\.")

        # Teste de conexão com a API
        sdk = mercadopago.SDK(token)
        test_response = sdk.payment().search({"limit": 1})
        
        if test_response['status'] not in [200, 201]:
            error_msg = test_response.get('response', {}).get('message', 'Erro na API')
            raise ValueError(f"Falha na validação: {error_msg}")

        # Salva no banco
        cursor.execute('INSERT INTO mp_tokens (token) VALUES (?)', (token,))
        conn.commit()
        
        # Confirmação com detalhes (CORRIGIDO)
        await update.message.reply_text(
            "✅ *TOKEN VALIDADO E SALVO\\!*\n\n"
            f"▸ Tipo: {'Produção' if 'prod' in token else 'Sandbox'}\n"
            f"▸ Primeiros caracteres: `{token[:12]}`\n"
            f"▸ Data/hora: {datetime.now().strftime('%d/%m/%Y %H:%M')}\n\n"
            "O sistema de pagamentos está operacional\\!",
            parse_mode="MarkdownV2"
        )
        
        # Notifica admins
        await notify_admins(
            context,
            f"🔔 Novo token MP configurado por @{update.effective_user.username}\n"
            f"▸ Ambiente: {'Produção' if 'prod' in token else 'Sandbox'}\n"
            f"▸ Token ID: `{token[8:20]}`"
        )

    except Exception as e:
        error_msg = (
            "❌ *ERRO NA VALIDAÇÃO DO TOKEN\\!*\n\n"
            f"Motivo: `{str(e)}`\n\n"
            "Verifique:\n"
            "1\\. Formato correto: `APP_USR\\-XXXX...`\n"
            "2\\. Token ativo no [Portal MP](https://www\\.mercadopago\\.com\\.br/developers)\n"
            "3\\. Permissões de produção ativadas\n\n"
            "Cole o token novamente:"
        )
        
        await update.message.reply_text(
            error_msg,
            parse_mode="MarkdownV2",
            disable_web_page_preview=True
        )
        logging.error(f"Falha no token {token[:15]}...: {str(e)}")
        return "WAITING_MP_TOKEN"
    
    return ConversationHandler.END
            
async def cancel_token_setup(update: Update, context: CallbackContext):
    """Cancela o processo de configuração"""
    await update.message.reply_text(
        "❌ Configuração do token cancelada",
        parse_mode="MarkdownV2"
    )
    return ConversationHandler.END
    
async def handle_file_upload(update: Update, context: CallbackContext):
       """Recebe e armazena o arquivo do app enviado pelo admin."""
       if update.effective_user.id not in ADMIN_IDS:
           await update.message.reply_text("❌ Acesso restrito a administradores!")
           return

       document = update.message.document
       if document and document.file_name.endswith('.apk'):
           file_id = document.file_id
           file_name = document.file_name

           # Armazena no banco de dados
           cursor.execute('''
               INSERT INTO app_files (file_id, file_name)
               VALUES (?, ?)
           ''', (file_id, file_name))
           conn.commit()

           await update.message.reply_text("✅ Arquivo .apk atualizado com sucesso!")
       else:
           await update.message.reply_text("⚠️ Por favor, envie um arquivo .apk válido.")
        
async def send_app_file(update: Update, context: CallbackContext):
    """Envia o arquivo para o usuário"""
    query = update.callback_query
    await query.answer()
    
    try:
        # Obtém o último arquivo cadastrado
        cursor.execute('SELECT file_id, file_name FROM app_files ORDER BY uploaded_at DESC LIMIT 1')
        file = cursor.fetchone()
        
        if file:
            file_id, file_name = file
            await context.bot.send_document(
                chat_id=query.message.chat_id,
                document=file_id,
                filename=file_name,
                caption=f"📥 {file_name}"
            )
        else:
            await query.message.reply_text("⚠️ Nenhum arquivo disponível no momento.")
            
    except Exception as e:
        logging.error(f"Erro ao enviar arquivo: {str(e)}")
        await query.message.reply_text("❌ Ocorreu um erro ao enviar o arquivo. Tente novamente mais tarde.")
                
async def notify_channel(context: CallbackContext, message: str):
    """Envia notificação para o canal oficial"""
    try:
        await context.bot.send_message(
            chat_id=REFERENCE_CHANNEL,
            text=message,
            parse_mode="Markdown"
        )
    except Exception as e:
        logging.error(f"Erro ao notificar canal: {str(e)}")

async def select_link_to_edit(update: Update, context: CallbackContext):
    """Seleciona qual link será editado"""
    query = update.callback_query
    await query.answer()
    
    link_type = query.data.split('_')[1]
    context.user_data['link_type'] = link_type
    
    await query.message.edit_text(
        f"🔗 Envie o novo link para {link_type.capitalize()}:"
    )
    return APP_LINK_EDIT

async def save_new_link(update: Update, context: CallbackContext):
    """Salva o novo link no banco de dados"""
    new_url = update.message.text
    link_type = context.user_data['link_type']
    
    # Validação básica de URL
    if not new_url.startswith('http'):
        await update.message.reply_text("❌ URL inválida! Deve começar com http/https")
        return APP_LINK_EDIT
    
    # Atualiza o banco de dados
    column = 'android_url' if link_type == 'android' else 'ios_url'
    cursor.execute(f'''
        UPDATE app_links 
        SET {column} = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = 1
    ''', (new_url,))
    conn.commit()
    
    await update.message.reply_text(f"✅ Link {link_type.upper()} atualizado com sucesso!")
    return ConversationHandler.END
        
# Crie o handler de conversa
mp_token_conv = ConversationHandler(
    entry_points=[
        CommandHandler('set_mp_token', start_set_token),
        CallbackQueryHandler(start_set_token, pattern='^set_mp_token$')
    ],
    states={
        "WAITING_MP_TOKEN": [MessageHandler(filters.TEXT & ~filters.COMMAND, save_mp_token)]
    },
    fallbacks=[
        CommandHandler('cancel', cancel_token_setup),
        CallbackQueryHandler(cancel_token_setup, pattern='^cancel$')
    ]
)

async def edit_plan(update: Update, context: CallbackContext):
    """Inicia o processo de edição de um plano."""
    query = update.callback_query
    await query.answer()
    
    plan_id = query.data.split('_')[2]  # Padrão: edit_plan_123
    context.user_data['edit_plan_id'] = plan_id  # Salva o ID do plano no contexto

    # Mostra os campos editáveis
    keyboard = [
        [InlineKeyboardButton("✏️ Nome", callback_data='edit_plan_name')],
        [InlineKeyboardButton("⏳ Duração (dias)", callback_data='edit_plan_duration_days')],
        [InlineKeyboardButton("💲 Preço", callback_data='edit_plan_price')],
        [InlineKeyboardButton("🔙 Voltar", callback_data='admin_menu')]
    ]

    await query.message.edit_text(
        "📝 Selecione o campo que deseja editar:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    return EDIT_PLAN_FIELD
           
async def edit_plan_value(update: Update, context: CallbackContext):
    """Salva o novo valor no banco de dados."""
    new_value = update.message.text.strip()
    plan_id = context.user_data.get('edit_plan_id')  # Obtém o ID do plano do contexto
    field = context.user_data.get('edit_plan_field')  # Obtém o campo a ser editado do contexto

    # Lista de campos permitidos
    allowed_fields = {'name', 'duration_days', 'price'}
    if field not in allowed_fields:
        await update.message.reply_text("❌ Campo inválido! Escolha um campo válido.")
        return ConversationHandler.END

    try:
        # Validação e conversão de valores
        if field == 'duration_days':
            if not new_value.isdigit():
                await update.message.reply_text("❌ A duração deve ser um número inteiro. Tente novamente:")
                return EDIT_PLAN_VALUE
            converted_value = int(new_value)
        elif field == 'price':
            try:
                converted_value = float(new_value)
            except ValueError:
                await update.message.reply_text("❌ O preço deve ser um número. Use ponto para decimais (ex: 29.90):")
                return EDIT_PLAN_VALUE
        else:  # name
            converted_value = new_value

        # Atualização segura usando parâmetros nomeados
        cursor.execute(f'''
            UPDATE plans 
            SET {field} = :value 
            WHERE id = :id
        ''', {'value': converted_value, 'id': plan_id})
        conn.commit()

        await update.message.reply_text(f"✅ Campo *{field.replace('_', ' ')}* atualizado para `{converted_value}`!", parse_mode="Markdown")

    except sqlite3.Error as e:
        logging.error(f"Erro no banco de dados: {str(e)}")
        await update.message.reply_text("❌ Erro interno ao atualizar o plano. Tente novamente.")
    except Exception as e:
        logging.error(f"Erro inesperado: {str(e)}")
        await update.message.reply_text("❌ Ocorreu um erro inesperado. Verifique os dados e tente novamente.")

    return ConversationHandler.END
                
async def edit_plan_field(update: Update, context: CallbackContext):
    """Manipula a seleção do campo a ser editado."""
    query = update.callback_query
    await query.answer()

    # Obtém o campo a partir do callback_data, juntando as partes após 'edit_plan_'
    field = '_'.join(query.data.split('_')[2:])
    allowed_fields = {'name', 'duration_days', 'price'}
    
    if field not in allowed_fields:
        await query.message.reply_text("❌ Campo inválido! Escolha um campo válido.")
        return ConversationHandler.END
    
    context.user_data['edit_plan_field'] = field  # Salva o campo no contexto
    await query.message.edit_text(f"✏️ Digite o novo valor para {field.replace('_', ' ')}:")
    return EDIT_PLAN_VALUE
                                       
# Defina o ConversationHandler após a função
edit_plan_conv = ConversationHandler(
    entry_points=[CallbackQueryHandler(edit_plan, pattern='^edit_plan_')],
    states={
        EDIT_PLAN_FIELD: [CallbackQueryHandler(edit_plan_field, pattern='^edit_plan_')],
        EDIT_PLAN_VALUE: [MessageHandler(filters.TEXT & ~filters.COMMAND, edit_plan_value)]
    },
    fallbacks=[
        CommandHandler('cancel', cancel),
        CallbackQueryHandler(admin_menu, pattern='^admin_menu$')
    ]
)

async def disable_plan(update: Update, context: CallbackContext):
    """Desativa um plano selecionado."""
    query = update.callback_query
    await query.answer()
    
    plan_id = query.data.split('_')[2]  # Padrão: disable_plan_123

    # Atualiza o status do plano no banco de dados
    cursor.execute('''
        UPDATE plans 
        SET active = 0
        WHERE id = ?
    ''', (plan_id,))
    conn.commit()

    await query.message.edit_text(f"✅ Plano {plan_id} desativado com sucesso!")
    
async def list_plans_to_disable(update: Update, context: CallbackContext):
    """Lista planos ativos para desativação"""
    query = update.callback_query
    await query.answer()

    cursor.execute('SELECT * FROM plans WHERE active = 1')
    plans = cursor.fetchall()

    keyboard = []
    for plan in plans:
        keyboard.append([
            InlineKeyboardButton(
                f"{plan[1]} (ID: {plan[0]})",
                callback_data=f"disable_plan_{plan[0]}"
            )
        ])

    keyboard.append([InlineKeyboardButton("🔙 Voltar", callback_data='admin_menu')])

    await query.message.edit_text(
        "🚫 Selecione o plano para desativar:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    
async def manage_servers(update: Update, context: CallbackContext):
    """Mostra a lista de servidores para gerenciamento."""
    query = update.callback_query
    await query.answer()

    cursor.execute('SELECT * FROM servers')
    servers = cursor.fetchall()

    keyboard = []
    for server in servers:
        keyboard.append([
            InlineKeyboardButton(
                f"🖥 {server[1]}",
                callback_data=f"server_{server[0]}"
            ),
            InlineKeyboardButton(
                "❌ Excluir",
                callback_data=f"delete_server_{server[0]}"
            )
        ])

    keyboard.append([
        InlineKeyboardButton("➕ Adicionar Servidor", callback_data='add_server'),
        InlineKeyboardButton("🔙 Voltar", callback_data='admin_menu')
    ])

    await query.message.edit_text(
        "🖥️ Servidores cadastrados:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def delete_server(update: Update, context: CallbackContext):
    """Exclui um servidor selecionado."""
    query = update.callback_query
    await query.answer()
    
    server_id = query.data.split('_')[2]  # Padrão: delete_server_123

    # Remove o servidor do banco de dados
    cursor.execute('DELETE FROM servers WHERE id = ?', (server_id,))
    conn.commit()

    await query.message.edit_text(f"✅ Servidor {server_id} excluído com sucesso!")
    
async def manage_servers(update: Update, context: CallbackContext):
    """Mostra a lista de servidores para gerenciamento."""
    query = update.callback_query
    await query.answer()

    cursor.execute('SELECT * FROM servers')
    servers = cursor.fetchall()

    keyboard = []
    for server in servers:
        keyboard.append([
            InlineKeyboardButton(
                f"🖥 {server[1]}",
                callback_data=f"server_{server[0]}"
            ),
            InlineKeyboardButton(
                "❌ Excluir",
                callback_data=f"delete_server_{server[0]}"
            )
        ])

    keyboard.append([
        InlineKeyboardButton("➕ Adicionar Servidor", callback_data='add_server'),
        InlineKeyboardButton("🔙 Voltar", callback_data='admin_menu')
    ])

    await query.message.edit_text(
        "🖥️ Servidores cadastrados:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def delete_server(update: Update, context: CallbackContext):
    """Exclui um servidor selecionado."""
    query = update.callback_query
    await query.answer()
    
    server_id = query.data.split('_')[2]  # Padrão: delete_server_123

    # Remove o servidor do banco de dados
    cursor.execute('DELETE FROM servers WHERE id = ?', (server_id,))
    conn.commit()

    await query.message.edit_text(f"✅ Servidor {server_id} excluído com sucesso!")
    
async def broadcast_menu(update: Update, context: CallbackContext):
    """Menu de envio de mensagens"""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id not in ADMIN_IDS:
        await query.message.reply_text("❌ Acesso restrito!")
        return
    
    keyboard = [
        [InlineKeyboardButton("📢 Todos os usuários", callback_data='broadcast_all')],
        [InlineKeyboardButton("🔙 Voltar", callback_data='admin_menu')]
    ]
    
    await query.message.edit_text(
        "📤 *Menu de Envio de Mensagens*\nSelecione o público-alvo:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )
    return SELECT_BROADCAST_TYPE

async def select_broadcast_type(update: Update, context: CallbackContext):
    """Seleciona o tipo de broadcast"""
    query = update.callback_query
    await query.answer()
    context.user_data['broadcast_type'] = query.data
    
    if query.data == 'broadcast_specific':
        await query.message.edit_text("🔢 Digite o ID do usuário:")
        return BROADCAST
    
    await query.message.edit_text("📝 Digite a mensagem que deseja enviar (suporta Markdown):")
    return BROADCAST

async def get_broadcast_recipients(broadcast_type, specific_id=None):
    """Retorna a lista de destinatários com base no tipo"""
    try:
        if broadcast_type == 'broadcast_all':
            # Busca todos os usuários que já interagiram com o bot
            cursor.execute('SELECT DISTINCT user_id FROM payments')
            recipients = [row[0] for row in cursor.fetchall()]
            
            # Se a tabela payments estiver vazia, tenta buscar de outra tabela
            if not recipients:
                cursor.execute('SELECT DISTINCT user_id FROM trial_cooldown')
                recipients = [row[0] for row in cursor.fetchall()]
            
        elif broadcast_type == 'broadcast_active':
            # Busca usuários com pagamentos ativos
            cursor.execute('''
                SELECT DISTINCT user_id 
                FROM payments 
                WHERE status = 'approved' 
                AND expiry_date > datetime('now')
            ''')
            recipients = [row[0] for row in cursor.fetchall()]
            
        elif broadcast_type == 'broadcast_specific' and specific_id:
            # Verifica se o usuário específico existe
            cursor.execute('SELECT user_id FROM payments WHERE user_id = ?', (specific_id,))
            if cursor.fetchone():
                recipients = [int(specific_id)]
            else:
                cursor.execute('SELECT user_id FROM trial_cooldown WHERE user_id = ?', (specific_id,))
                if cursor.fetchone():
                    recipients = [int(specific_id)]
                else:
                    recipients = []
        
        else:
            recipients = []
        
        # Remove duplicatas e valores inválidos
        recipients = list(set(filter(lambda x: x is not None, recipients)))
        
        return recipients
    
    except sqlite3.Error as e:
        logging.error(f"Erro no banco de dados: {str(e)}")
        return []
    except Exception as e:
        logging.error(f"Erro inesperado: {str(e)}")
        return []
        
async def prepare_broadcast(update: Update, context: CallbackContext):
    """Prepara a mensagem para envio"""
    user_input = update.message.text
    
    if context.user_data['broadcast_type'] == 'broadcast_specific':
        if not user_input.isdigit():
            await update.message.reply_text("❌ ID inválido! Deve ser um número. Tente novamente:")
            return BROADCAST
        context.user_data['specific_id'] = user_input
        await update.message.reply_text("📝 Digite a mensagem para este usuário (suporta Markdown):")
        return BROADCAST
    
    context.user_data['broadcast_message'] = user_input
    recipients = await get_broadcast_recipients(
        context.user_data['broadcast_type'],
        context.user_data.get('specific_id')
    )
    
    if not recipients:
        await update.message.reply_text("❌ Nenhum destinatário encontrado!")
        return ConversationHandler.END
    
    context.user_data['recipients'] = recipients
    context.user_data['broadcast_message'] = user_input
    
    keyboard = [
        [InlineKeyboardButton("✅ Confirmar Envio", callback_data='confirm_broadcast')],
        [InlineKeyboardButton("❌ Cancelar", callback_data='cancel_broadcast')]
    ]
    
    await update.message.reply_text(
        f"⚠️ Confirmar envio para {len(recipients)} destinatários?\n\nPré-visualização:\n{user_input}",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode="Markdown"
    )
    return CONFIRM_BROADCAST

async def execute_broadcast(update: Update, context: CallbackContext):
    """Executa o envio das mensagens"""
    query = update.callback_query
    await query.answer()
    
    if query.data == 'cancel_broadcast':
        await query.message.edit_text("❌ Envio cancelado!")
        return ConversationHandler.END
    
    recipients = context.user_data['recipients']
    message = context.user_data['broadcast_message']
    total = len(recipients)
    success = 0
    failed = []
    
    await query.message.edit_text(f"⏳ Enviando para {total} usuários...")
    
    for user_id in recipients:
        try:
            await context.bot.send_message(
                chat_id=user_id,
                text=message,
                parse_mode="Markdown"
            )
            success += 1
        except Exception as e:
            logging.error(f"Erro ao enviar para {user_id}: {str(e)}")
            failed.append(user_id)
        await asyncio.sleep(0.1)  # Evita flood
    
    # Relatório de envio
    report = (
        f"📊 *Relatório de Envio*\n\n"
        f"✅ Sucesso: {success}\n"
        f"❌ Falhas: {len(failed)}\n"
        f"📝 Mensagem: {message[:50]}..."
    )
    
    if failed:
        report += "\n\nIDs com falha:\n" + ", ".join(map(str, failed[:20]))  # Limita a 20 IDs
    
    await query.message.reply_text(report, parse_mode="Markdown")
    
    # Limpa dados temporários
    context.user_data.clear()
    return ConversationHandler.END

# Adicione ao ConversationHandler existente
broadcast_conv = ConversationHandler(
    entry_points=[CallbackQueryHandler(broadcast_menu, pattern='^broadcast$')],
    states={
        SELECT_BROADCAST_TYPE: [CallbackQueryHandler(select_broadcast_type, pattern='^broadcast_')],
        BROADCAST: [MessageHandler(filters.TEXT & ~filters.COMMAND, prepare_broadcast)],
        CONFIRM_BROADCAST: [CallbackQueryHandler(execute_broadcast, pattern='^(confirm|cancel)_broadcast$')]
    },
    fallbacks=[
        CommandHandler('cancel', cancel),
        CallbackQueryHandler(admin_menu, pattern='^admin_menu$')
    ]
)

async def force_update_notify(update: Update, context: CallbackContext):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text("❌ Acesso restrito!")
        return
    
    cursor.execute('SELECT file_name FROM app_files ORDER BY uploaded_at DESC LIMIT 1')
    file = cursor.fetchone()
    
    if file:
        version = file[0].split('.')[0]
        await notify_channel(
            context,
            f"🆕 *ATUALIZAÇÃO DISPONÍVEL!*\n\n"
            f"🔸 Versão: {version}\n"
            f"🔸 Data: {datetime.now().strftime('%d/%m/%Y')}\n\n"
            f"⚠️ Atualize seu aplicativo agora para melhor performance e novos recursos!"
        )
        await update.message.reply_text("✅ Notificação de atualização enviada ao canal!")
    else:
        await update.message.reply_text("❌ Nenhum arquivo cadastrado!")

def main():
    application = ApplicationBuilder().token(TOKEN).build()

    # Adicione primeiro o handler do token
    application.add_handler(mp_token_conv)

    # Configuração dos ConversationHandlers
    conv_handler_add_server = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(add_server, pattern='add_server'),
            CommandHandler('addserver', add_server)
        ],
        states={
            SERVER_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, server_name)],
            SERVER_HOST: [MessageHandler(filters.TEXT & ~filters.COMMAND, server_host)],
            SERVER_PORT: [MessageHandler(filters.TEXT & ~filters.COMMAND, server_port)],
            SERVER_USER: [MessageHandler(filters.TEXT & ~filters.COMMAND, server_user)],
            SERVER_PASS: [MessageHandler(filters.TEXT & ~filters.COMMAND, server_pass)]
        },
        fallbacks=[
            CommandHandler('cancel', lambda u, c: ConversationHandler.END),
            CallbackQueryHandler(manage_servers, pattern='manage_servers')
        ]
    )

    conv_handler_add_plan = ConversationHandler(
        entry_points=[CallbackQueryHandler(add_plan, pattern='add_plan')],
        states={
            PLAN_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, plan_name)],
            PLAN_DURATION: [MessageHandler(filters.TEXT & ~filters.COMMAND, plan_duration)],
            PLAN_PRICE: [MessageHandler(filters.TEXT & ~filters.COMMAND, plan_price)]
        },
        fallbacks=[CommandHandler('cancel', lambda u, c: ConversationHandler.END)]
    )

    conv_handler_renewal = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(renew_access, pattern='renew'),
            CommandHandler('renovar', renew_access)
        ],
        states={
            "AWAITING_RENEWAL_USERNAME": [MessageHandler(filters.TEXT, handle_renewal_username)],
            "AWAITING_RENEWAL_EMAIL": [MessageHandler(filters.TEXT, handle_renewal_email)]
        },
        fallbacks=[CommandHandler('cancel', cancel)]
    )

    conv_handler_edit_renewal = ConversationHandler(
        entry_points=[CommandHandler('editar_renovacao', edit_renewal)],
        states={
            "AWAITING_RENEWAL_DAYS": [MessageHandler(filters.TEXT, set_renewal_days)],
            "AWAITING_RENEWAL_PRICE": [MessageHandler(filters.TEXT, set_renewal_price)]
        },
        fallbacks=[CommandHandler('cancel', cancel)]
    )

    # Adicionando os handlers
    application.add_handler(conv_handler_renewal)
    application.add_handler(broadcast_conv)
    application.add_handler(conv_handler_edit_renewal)
    application.add_handler(conv_handler_add_server)
    application.add_handler(conv_handler_add_plan)

    # Handlers para upload de arquivos
    # O handler de .db deve vir antes do handler de .apk
    application.add_handler(MessageHandler(
        filters.Document.FileExtension("db") & filters.User(ADMIN_IDS),
        restore_backup
    ))
    application.add_handler(MessageHandler(
        filters.Document.FileExtension("apk") & filters.User(ADMIN_IDS),
        handle_file_upload
    ))
    application.add_handler(MessageHandler(
        filters.Document.ALL & filters.User(ADMIN_IDS),
        handle_file_upload
    ))

    # Outros handlers
    application.add_handler(CommandHandler('start', start))
    application.add_handler(CallbackQueryHandler(start, pattern='^start$'))
    application.add_handler(edit_plan_conv)
    application.add_handler(CommandHandler("backup", create_backup))
    application.add_handler(CallbackQueryHandler(disable_plan, pattern='^disable_plan_'))
    application.add_handler(CallbackQueryHandler(send_app_file, pattern='^download_app$'))
    application.add_handler(CallbackQueryHandler(manage_servers, pattern='^manage_servers$'))
    application.add_handler(CommandHandler('notificar_atualizacao', force_update_notify))
    application.add_handler(CallbackQueryHandler(delete_server, pattern='^delete_server_'))
    application.add_handler(CallbackQueryHandler(send_app_file, pattern='^send_app$'))
    application.add_handler(CallbackQueryHandler(list_plans_to_disable, pattern='^list_plans_to_disable$'))
    application.add_handler(CallbackQueryHandler(admin_menu, pattern='admin_menu'))
    application.add_handler(CallbackQueryHandler(edit_plans, pattern='edit_plans'))
    application.add_handler(CallbackQueryHandler(start_set_token, pattern='^set_mp_token$'))
    application.add_handler(CallbackQueryHandler(show_plans, pattern='buy'))
    application.add_handler(CallbackQueryHandler(handle_plan_selection, pattern='^plan_'))
    application.add_handler(CallbackQueryHandler(create_trial_user_v2, pattern='^trial$'))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_payment_email))

    application.run_polling()

if __name__ == '__main__':
    main()    
    
 