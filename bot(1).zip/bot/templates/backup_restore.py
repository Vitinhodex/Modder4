import shutil
import os
import datetime
import logging
import sqlite3
from telegram import Update
from telegram.ext import CallbackContext

# Configurações (ajuste conforme necessário)
DATABASE_PATH = "servidoar.db"  # Caminho do banco de dados usado no seu script
BACKUP_DIR = "backups/"         # Diretório para backups
ADMIN_IDS = [5175657643, 987654321]  # Seus IDs diretamente no código

# Certifica-se de que o diretório de backups existe
if not os.path.exists(BACKUP_DIR):
    os.makedirs(BACKUP_DIR)

# Conexão global com o banco de dados
conn = sqlite3.connect(DATABASE_PATH, check_same_thread=False)
cursor = conn.cursor()

async def create_backup(update: Update, context: CallbackContext):
    """Cria um backup do banco de dados e envia ao administrador."""
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text("❌ Acesso restrito a administradores!")
        return

    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_file = f"{BACKUP_DIR}/servidoar_backup_{timestamp}.db"

    try:
        # Copia o banco de dados para o arquivo de backup
        shutil.copy(DATABASE_PATH, backup_file)
        logging.info(f"Backup criado: {backup_file}")

        # Envia o arquivo ao administrador
        with open(backup_file, 'rb') as file:
            await context.bot.send_document(
                chat_id=update.effective_user.id,
                document=file,
                filename=f"servidoar_backup_{timestamp}.db",
                caption=f"✅ Backup do banco de dados - {timestamp}"
            )
        logging.info("Backup enviado ao administrador.")
    except Exception as e:
        logging.error(f"Erro ao criar/enviar backup: {e}")
        await update.message.reply_text(f"❌ Erro ao criar backup: {e}")

async def restore_backup(update: Update, context: CallbackContext):
       """Restaura o banco de dados a partir de um arquivo .db enviado pelo admin."""
       if update.effective_user.id not in ADMIN_IDS:
           await update.message.reply_text("❌ Acesso restrito a administradores!")
           return

       document = update.message.document
       if document and document.file_name.endswith('.db'):
           file = await context.bot.get_file(document.file_id)
           temp_file = "temp_restore.db"
           await file.download_to_drive(temp_file)

           # Verifica se o arquivo é um SQLite válido
           try:
               test_conn = sqlite3.connect(temp_file)
               test_conn.cursor().execute("SELECT name FROM sqlite_master LIMIT 1")
               test_conn.close()
           except sqlite3.Error:
               os.remove(temp_file)
               await update.message.reply_text("❌ Arquivo .db inválido ou corrompido")
               return

           # Restaura o banco de dados
           shutil.copy(temp_file, DATABASE_PATH)
           os.remove(temp_file)

           await update.message.reply_text("✅ Banco de dados restaurado com sucesso!")
       else:
           await update.message.reply_text("⚠️ Por favor, envie um arquivo .db válido.")          
          
          
